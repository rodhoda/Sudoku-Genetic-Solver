g++ DeterministicSudoku.cpp -o recursive
./recursive
