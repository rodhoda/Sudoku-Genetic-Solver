# Homework4-343-Project-4

Algorithm analysis includes findings with the algorithm as well as output screenshots from several different workstations. 

Algorithm design analysis can be found at: https://docs.google.com/document/d/1HiqjCib8lzdk5AfZaS-KgSnrNWr5evPXm-rg_hpbp7U/edit?usp=sharing

Main program is in Homework4 343 Folder 

Program runs with test.sh command file within the folder. This will link all the .cpp files and run the program right away. 


There is a blank space in Homework4 343 name, thereforce in linux you must use \ to get to the directory. 

Deterministic extra credit in Deterministic folder - this also has its own sh file called recursive.sh 

Deterministic Approach - When we ran this, we had to remove the genetic algorithm program from our Linux Lab directory due to sizing issues. Remove genetic algorithm after testing and before testing deterministic approach. 

Both projects complete and run. 


PLEASE NOTE:

Compiler warnings do arise in the Linux test enviroment (they do not exist in our windows' enviroments), 
but, the code can still be linked and compiled despite the warnings. 

NOTE TWO: 

Algorithm bases how much to show off user input. Upon starting the algorithm, it may look like its hanging, however, it only displays in increments. I.e., 50,000 generations requested at the command line will produce results every 5000.

