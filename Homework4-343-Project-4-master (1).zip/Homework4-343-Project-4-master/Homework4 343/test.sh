g++ *.cpp -o SudokuSolver
./SudokuSolver
